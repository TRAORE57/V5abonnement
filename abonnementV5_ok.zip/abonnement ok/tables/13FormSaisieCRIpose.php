
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Demande d'abonnement-branchement</title>
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
<?php
 // demarrage du processus et  envoyer des donnees à camunda 
require_once('camundaRestClient.php');
$restClient = new camundaRestClient('http://localhost:8080/engine-rest');
$processeid =$restClient->getProcessInstances();
//var_dump($processeid);exit;
$variables=$restClient->getProcessVariables($processeid['0']->id);
//var_dump($variables); exit;
?>
  <div class="container">
  <h1>BRANCHEMENT-ABONNEMENT</h1>
    <div class="title">SAISIE COMPTE RENDU DE POSE</div>
    <div class="content">
      <form action="13traiterSaisieCRIpose.php" method="POST" enctype='multipart/form-data' >
        <div class="user-details">
        <div class="input-box">
            <span class="details"><strong>Rapport de pose </strong></span>
            <input type="text"  name="rapportPose" required>
          </div>
          <div class="input-box">
            <span class="details"><strong>Date de pose éffective :</strong></span>
            <input type="date"  name="dateposeeffective" required>
          </div>
          <div class="input-box">
            <span class="details"><strong>Date de pose prévue :</strong></span>
            <input type="date" value="<?=$variables->dateposeprevue->value?>" name="dateposeprevue" readonly>
          </div>
          <div class="input-box">
            <span class="details"><strong>Agent d'installation :</strong></span>
            <input type="text" value="<?=$variables->agentTerrain->value?>" name="agentTerrain" readonly>
          </div>
          <div class="input-box">
            <span class="details"><strong>Numero compteur</strong></span>
            <input type="number" value="<?=$variables->numeroCompteur->value?>" name="numeroCompteur" readonly>
          </div>

        <div class="button">
          <input type="submit" value="Continuer">
        </div>
      </form>
    </div>
  </div>

</body>
</html>
