<?php
$non="false";
$reponse=$_POST['accord'];
if ($reponse==$non) {
  header('Location: index.php');
}else{
  //var_dump($_POST);exit;
// demarrage du processus et  envoyer des donnees à camunda 
require_once('camundaRestClient.php');
$restClient = new camundaRestClient('http://localhost:8080/engine-rest');
// recuperation et envoi des données du formulaire vers camunda  
$params=[
		"accord"=>['value'=>$_POST['accord'],'type'=>'string']
    ];
$params =['variables'=>$params];
//recuperation de s  tâches assignées à l'utilisateur 'ac'
$results = $restClient->getTasks(['assigned'=>true,'assignee'=>'ac']);
//recuperation de l'ID
$id= $results['0']->id;
//var_dump($results,$params);exit;
//envoyer les données  et passer à l'étape validation devis
$envoyer = $restClient->postForm($id,$params);
header('Location: 9FormEchelonnement.php');
}

?>
