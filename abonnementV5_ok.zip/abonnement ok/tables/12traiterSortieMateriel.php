<?php
//var_dump($_POST);exit;
// demarrage du processus et  envoyer des donnees à camunda 
require_once('camundaRestClient.php');
$restClient = new camundaRestClient('http://localhost:8080/engine-rest');
//recuperation de s  tâches assignées à l'utilisateur 'ac'
$results = $restClient->getTasks(['assigned'=>true,'assignee'=>'rgs']);
//recuperation de l'ID
$id= $results['0']->id;
//var_dump($results,$params);exit;
//envoyer les données  et passer à l'étape validation devis
//parametre et nom de celui qui est sensé terminer la tache
$params= [ 
	"variables"=>[
		"approver"=>[ 
			"value"=>'rgs',
			"type"=>'string'
		]
	]
];
// appel de la fonction completeTask pour mettre fin a la tache et aller au cri compte rendu de pose
$fini =$restClient->completeTask($id,$params);
header('Location: 13FormSaisieCRIpose.php');

?>