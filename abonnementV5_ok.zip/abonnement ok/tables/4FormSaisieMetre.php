
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Demande d'abonnement-branchement</title>
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
<?php
 // demarrage du processus et  envoyer des donnees à camunda 
require_once('camundaRestClient.php');
$restClient = new camundaRestClient('http://localhost:8080/engine-rest');
$processeid =$restClient->getProcessInstances();
//regler le soucis d'index ici car il varie
$tache=$restClient->getTasks();

//var_dump($tache);exit;
$variables=$restClient->getProcessVariables($processeid['0']->id);
//var_dump($variables); exit;
?>
  <div class="container">
  <h1>BRANCHEMENT-ABONNEMENT</h1>
    <div class="title">SAISIE COMPTE RENDU METRIE</div>
    <div class="content">
      <form action="4traiterSaisieMetre.php" method="POST" enctype='multipart/form-data' >
        <div class="user-details">
          <div class="input-box">
            <span class="details"><strong>Rapport metrie :</strong></span>
            <textarea cols="42" rows="3" placeholder=" ajoutez  votre rapport" name="rapportterrain" required></textarea>
          </div>
          <div class="select-box">
            <span class="details"><strong>AMPERAGE:</strong></span>
            <select name="materiel" id="materiel" required>
              <option value="">Selectionnez l'amperage</option>
              <option  value="5 A">5 A</option>
              <option  value="10 A">10 A</option>
              <option value="15 A">15 A</option>
              <option value="20 A">20 A</option>
            </select>
          </div>
          <div class="input-box">
            <span class="details"><strong>Agent en charge de l'operation</strong></span>
            <input type="text" value="<?=$variables->agentTerrain->value?>" name="agentTerrain" readonly>
          </div>
          <div class="input-box">
            <span class="details"><strong>Date de viste théorique :</strong></span>
            <input type="date" value=<?=$variables->datevisite->value?> name="datevisite" readonly>
          </div>
          <div class="input-box">
            <span class="details"><strong>Date de viste effective :</strong></span>
            <input type="date" placeholder=" ajoutez la date de viste effective" name="datevisiteeffective" required>
          </div>

        <div class="button">
          <input type="submit" value="Continuer">
        </div>
      </form>
    </div>
  </div>

</body>
</html>
