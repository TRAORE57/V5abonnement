
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Demande d'abonnement-branchement</title>
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
<?php
 // demarrage du processus et  envoyer des donnees à camunda 
require_once('camundaRestClient.php');
$restClient = new camundaRestClient('http://localhost:8080/engine-rest');
$processeid =$restClient->getProcessInstances();
$variables=$restClient->getProcessVariables($processeid['0']->id);
//var_dump($variables); exit;
?>
  <div class="container">
  <h1>BRANCHEMENT-ABONNEMENT</h1>
    <div class="title">ACCORD CLIENT</div>
    <div class="content">
      <form action="8traiterAccordClient.php" method="POST" enctype='multipart/form-data' >
        <div class="user-details">
        <div class="input-box">
            <span class="details"><strong>Type de compteur</strong></span>
            <input type="text" value="<?=$variables->rapportterrain->value?>" name="rapportterrain" readonly>
          </div>
          <div class="input-box">
            <span class="details"><strong>Materiels demandés :</strong></span>
            <input type="text" value="<?=$variables->materiel->value?>" name="materiel" readonly>
          </div>
          <div class="input-box">
            <span class="details"><strong>Coût du materiel :</strong></span>
            <input type="text" value="<?=$variables->coutMateriel->value?>" name="coutMateriel" readonly>
          </div>
          <div class="input-box">
            <span class="details"><strong>Coût du service ou de la main d'ouevre:</strong></span>
            <input type="text" value="<?=$variables->coutMain->value?>" name="coutMain" readonly>
          </div>
          <div class="input-box">
            <span class="details"><strong>Coût total de l'abonnement :</strong></span>
            <input type="text" value="<?=$variables->total->value?>" name="total" readonly>
          </div>
          <div class="select-box">
            <span class="details"><strong> Reponse ou accord du client</strong></span>
            <select name="accord" id="accord" required>
              <option value="">selectionnez un avis</option>
              <option  value="true">OUI</option>
              <option  value="false">NON</option>
            </select>
          </div>

        <div class="button">
          <input type="submit" value="Continuer">
        </div>
      </form>
    </div>
  </div>

</body>
</html>
