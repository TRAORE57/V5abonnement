
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Demande d'abonnement-branchement</title>
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
<?php
 // demarrage du processus et  envoyer des donnees à camunda 
require_once('camundaRestClient.php');
$restClient = new camundaRestClient('http://localhost:8080/engine-rest');
$processeid =$restClient->getProcessInstances();
$variables=$restClient->getProcessVariables($processeid['4']->id);
//var_dump($variables); exit;
?>
  <div class="container">
  <h1>BRANCHEMENT-ABONNEMENT</h1>
    <div class="title">ECHELONNEMENT</div>
    <div class="content">
      <form action="9traiterEchelonnement.php" method="POST" enctype='multipart/form-data' >
        <div class="user-details">
          <div class="select-box">
            <span class="details"><strong>Echelonnement :</strong></span>
            <select name="echelonnement" id="echelonnement" required>
              <option value="">selectionnez....</option>
              <option  value="TOTALITE">PAYEMENT TOTAL</option>
              <option  value="SEMAINE">PAYER PAR SEMAINE</option>
              <option  value="MOIS">PAYER PAR MOIS</option>
            </select>
          </div>

        <div class="button">
          <input type="submit" value="Continuer">
        </div>
      </form>
    </div>
  </div>

</body>
</html>
