
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Demande de conges</title>
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="container">
  <h1>BRANCHEMENT-ABONNEMENT</h1>
    <div class="title">QUALIFICATION DE LA DEMANDE</div>
    <div class="content">
      <form action="1traiterQualification.php" method="POST" enctype='multipart/form-data' >
        <div class="user-details">
          <div class="input-box">
            <span class="details"><strong>Nom et prenom(s) du client</strong> </span>
            <input type="text" name="nomprenom" placeholder="Entrez le nom complet du client" required>
          </div>
          <div class="select-box">
            <span class="details"><strong>Civilité</strong></span>
            <!--<input type="file" name="service" placeholder="Entrer le service" required>-->
            <select name="civilite" id="civilite" required>
              <option value="">Selectionnez l a civilité</option>
              <option value="MONSIEUR">MONSIEUR</option>
              <option value="MADAME">MADAME</option>
              <option value="AUTRE">AUTRE</option>
            </select>
          </div>
          <div class="input-box">
            <span class="details"><strong>E-mail du client</strong></span>
            <input type="text" placeholder="cie.@gmail.ci" name="email" required>
          </div>
          <div class="select-box">
            <span class="details"><strong>Genre de client</strong></span>
            <!--<input type="file" name="service" placeholder="Entrer le service" required>-->
            <select name="genreClient" id="genreClient" required>
              <option value="">Selectionnez le service</option>
              <option value="SOCIETE">SOCIETE</option>
              <option value="PARTICULIER">PARTICULIER</option>
              <option value="ADMINISTRATION">ADMINISTRATION</option>
            </select>
          </div>
          <div class="input-box">
            <span class="details"><strong>Ville/Commune</strong></span>
            <input type="text" placeholder="ABIDJAN/COCODY" name="habitation" required>
          </div>
          <div class="input-box">
            <span class="details"><strong>Quartier/Secteur</strong></span>
            <input type="text" placeholder="MERMOZ / CITE" name="quatierSecteur" required>
          </div>
          <div class="input-box">
            <span class="details"><strong>Numéro de téléphone du client</strong></span>
            <input type='number_format' maxlength="10" placeholder="0700000000"  name="numeroTelephone" required>
          </div>
          <div class="select-box">
            <span class="details"><strong>Moyen de reception de la facture</strong></span>
            <!--<input type="file" name="service" placeholder="Entrer le service" required>-->
            <select name="livrerFacture" id="livrerFacture" required>
              <option value="">Selectionnez le moyen de recption</option>
              <option value="BUREAU">RECEVOIR LA FACTURE AU BUREAU</option>
              <option value="DOMICILE">RECEVOIR LA FACTURE A DOMICILE</option>
              <option value="E-MAIL">RECEVOIR LA FACTURE PAR E-MAIL</option>
            </select>
          </div>
          <div class="input-box">
            <span class="details"><strong>Date de naissance du client</strong></span>
            <input type="date" placeholder="date de naissance du client" name="dateNaissance" required>
          </div>
        </div>
        <div class="button">
          <input type="submit" value="Envoyer">
        </div>
      </form>
    </div>
  </div>

</body>
</html>
