<?php
// demarrage du processus et  envoyer des donnees à camunda 
require_once('camundaRestClient.php');
$restClient = new camundaRestClient('http://localhost:8080/engine-rest');
// recuperation et envoi des données du formulaire vers camunda  
$params=[
		"agentTerrain"=>['value'=>$_POST['agentTerrain'],'type'=>'string'],
		"datevisite"=>['value'=>$_POST['datevisite'],'type'=>'string']
		];
$params =['variables'=>$params];
//recuperation de s  tâches assignées à l'utilisateur 'ac'
$results = $restClient->getTasks(['assigned'=>true,'assignee'=>'aec']);
//recuperation de l'ID
$id= $results['0']->id;
//envoyer les données  et passer à l'étape saisir metre
$envoyer = $restClient->postForm($id,$params);
header('Location: 4FormSaisieMetre.php');

?>
