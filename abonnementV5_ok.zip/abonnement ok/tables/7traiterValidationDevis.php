<?php
$non="false";
$reponse=$_POST['autoriser'];
if ($reponse==$non) {
  header('Location: 6FormConstitutionDevis.php');
}else{
  //var_dump($_POST);exit;
// demarrage du processus et  envoyer des donnees à camunda 
require_once('camundaRestClient.php');
$restClient = new camundaRestClient('http://localhost:8080/engine-rest');
// recuperation et envoi des données du formulaire vers camunda  
$params=[
		"autoriser"=>['value'=>$_POST['autoriser'],'type'=>'string']
    ];
$params =['variables'=>$params];
//recuperation de s  tâches assignées à l'utilisateur 'ac'
$results = $restClient->getTasks(['assigned'=>true,'assignee'=>'rt']);
//recuperation de l'ID
$id= $results['0']->id;
//var_dump($results,$params);exit;
//envoyer les données  et passer à l'étape validation devis
$envoyer = $restClient->postForm($id,$params);
header('Location: 8FormAccordClient.php');
}

?>
