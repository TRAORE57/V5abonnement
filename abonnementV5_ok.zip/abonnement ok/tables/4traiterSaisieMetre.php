<?php
//var_dump($_POST);exit;
// demarrage du processus et  envoyer des donnees à camunda 
require_once('camundaRestClient.php');
$restClient = new camundaRestClient('http://localhost:8080/engine-rest');
// recuperation et envoi des données du formulaire vers camunda  
$params=[
		"rapportterrain"=>['value'=>$_POST['rapportterrain'],'type'=>'string'],
		"materiel"=>['value'=>$_POST['materiel'],'type'=>'string'],
        "datevisiteeffective"=>['value'=>$_POST['datevisiteeffective'],'type'=>'string']
		];
$params =['variables'=>$params];
//recuperation de s  tâches assignées à l'utilisateur 'ac'
$results = $restClient->getTasks(['assigned'=>true,'assignee'=>'aec']);
//recuperation de l'ID
$id= $results['0']->id;
//var_dump($results);exit;
//envoyer les données  et passer à l'étape validation
$envoyer = $restClient->postForm($id,$params);
header('Location: 5FormValidationMetrie.php');

?>
