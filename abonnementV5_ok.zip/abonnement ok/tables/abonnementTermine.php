
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Demande d'abonnement-branchement</title>
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="container">
    <div class="title"><h3>FIN BRANCHEMENT-ABONNEMENT</h3></div>
    <div class="content">
      <form action="" method="POST" enctype='multipart/form-data' >
        <div class="user-details">
            <h1><strong>MERCI !!!!!</strong></h1>
        </div>
      </form>
    </div>
  </div>

</body>
</html>
