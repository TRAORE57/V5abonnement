
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Demande d'abonnement-branchement</title>
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
<?php
 // demarrage du processus et  envoyer des donnees à camunda 
require_once('camundaRestClient.php');
$restClient = new camundaRestClient('http://localhost:8080/engine-rest');
$processeid =$restClient->getProcessInstances();
//var_dump($processeid);exit;
$variables=$restClient->getProcessVariables($processeid['0']->id);
//var_dump($variables); exit;
?>
  <div class="container">
  <h1>BRANCHEMENT-ABONNEMENT</h1>
    <div class="title">VALIDATION CRI DE POSE</div>
    <div class="content">
      <form action="14traiterValidationCRIpose.php" method="POST" enctype='multipart/form-data' >
        <div class="user-details">
        <div class="input-box">
            <span class="details"><strong>Rapport de pose </strong></span>
            <input type="text" value="<?=$variables->rapportPose->value?>" name="rapportPose" readonly>
          </div>
          <div class="input-box">
            <span class="details"><strong>Date de pose éffective :</strong></span>
            <input type="date" value="<?=$variables->dateposeeffective->value?>" name="dateposeeffective" readonly>
          </div>
          <div class="input-box">
            <span class="details"><strong>Date de pose prévue :</strong></span>
            <input type="date" value="<?=$variables->dateposeprevue->value?>" name="dateposeprevue" readonly>
          </div>
          <div class="input-box">
            <span class="details"><strong>Agent d'installation :</strong></span>
            <input type="text" value="<?=$variables->agentTerrain->value?>" name="agentTerrain" readonly>
          </div>
          <div class="input-box">
            <span class="details"><strong>Numero compteur</strong></span>
            <input type="number" value="<?=$variables->numeroCompteur->value?>" name="numeroCompteur" readonly>
          </div>
          <div class="select-box">
            <span class="details"><strong> Avis du responsable</strong></span>
            <select name="evaluer" id="evaluer" required>
              <option value="">selectionnez un avis</option>
              <option  value="true">OUI</option>
              <option  value="false">NON</option>
            </select>
          </div>


        <div class="button">
          <input type="submit" value="Continuer">
        </div>
      </form>
    </div>
  </div>

</body>
</html>
