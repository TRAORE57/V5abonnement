<?php

//var_dump($_POST);
// demarrage du processus et  envoyer des donnees à camunda
require_once('camundaRestClient.php');
$restClient = new camundaRestClient('http://localhost:8080/engine-rest');
// recuperation et envoi des données du formulaire et constitution d'un tableau pour la requête vers camunda
$params=[
		"nomprenom"=>['value'=>$_POST['nomprenom'],'type'=>'string'],
		"genreClient"=>['value'=>$_POST['genreClient'],'type'=>'string'], 
		"civilite"=>['value'=>$_POST['civilite'],'type'=>'string'],
		"email"=>['value'=>$_POST['email'],'type'=>'string'],
		"habitation"=>['value'=>$_POST['habitation'],'type'=>'string'],
		"numeroTelephone"=>['value'=>$_POST['numeroTelephone'],'type'=>'string'],
		"livrerFacture"=>['value'=>$_POST['livrerFacture'],'type'=>'string'],
        "quatierSecteur"=>['value'=>$_POST['quatierSecteur'],'type'=>'string'],
		"dateNaissance"=>['value'=>$_POST['dateNaissance'],'type'=>'string']
		];
//var_dump($params); exit;
 
$currentExecution = $restClient->startProcessInstance("abonn-branch",["variables"=>$params]);
// var_dump($result);
$executionId=$currentExecution->id; //id du processu courent ou de l'instance en cours
$tache = $restClient->getTasks(['assigned'=>true,'assignee'=>'ac','executionId'=>$executionId]);
//parametre de celui qui est habilité à mettre fin a la tâche
$paramsFin= [ 
	"variables"=>[
		"approver"=>[
			"value"=>'ac',
			"type"=>'string'
		]
	]
];
//var_dump($tache);
//achevenent de la tâche
$acheverTache =$restClient->completeTask($tache[0]->id,$paramsFin);
//var_dump($acheverTache);
header('Location: 2FormDocument.php');

?>