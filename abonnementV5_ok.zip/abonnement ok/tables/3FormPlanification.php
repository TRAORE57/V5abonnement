
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Demande d'abonnement-branchement</title>
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="container">
  <h1>BRANCHEMENT-ABONNEMENT</h1>
    <div class="title">PLANIFICATION METRE</div>
    <div class="content">
      <form action="3traiterPlanification.php" method="POST" enctype='multipart/form-data' >
        <div class="user-details">
          <div class="select-box">
            <span class="details"><strong>Agent Terrain ou visiteur :</strong></span>
            <select name="agentTerrain" id="agentTerrain" required>
              <option value="">Selectionnez un agent pour la visite</option>
              <option  value="CHARLES KOFFI DIBI KONE">CHARLES KOFFI DIBI KONE</option>
              <option  value="SORO KONAN KOUAKOU BERTIN">SORO KONAN KOUAKOU BERTIN</option>
              <option value="TOURE ABOUBACAR">TOURE ABOUBACAR</option>
              <option value="SERY TAPE DIANNEY">SERY TAPE DIANNEY</option>
              <option value="SAMATIGUILA YAMOUE">SAMATIGUILA YAMOUE</option>
              <option value="SAMAKE DJIBRIL">SAMAKE DJIBRIL</option>
              <option value="OUATTARA LOBATCHAI">OUATTARA LOBATCHAI</option>
              <option value="KOUAKOU JEANS YVES">KOUAKOU JEANS YVES</option>
              <option value="SELIKE MEA ALEX">SELIKE MEA ALEX</option>
            </select>
          </div>
          <div class="input-box">
            <span class="details">Dte de viste théorique :</span>
            <input type="date" placeholder=" ajoutez un date" name="datevisite" required>
          </div>

        <div class="button">
          <input type="submit" value="Continuer">
        </div>
      </form>
    </div>
  </div>

</body>
</html>
