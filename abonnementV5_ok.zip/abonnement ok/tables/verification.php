<?php
$pers=$_POST['personnes']; 
//var_dump($pers);exit;
session_start();
$at="at"; $client="client"; $caisse="caisse"; $ac="ac"; $rt="rt"; $rc="rc"; $rgs="rgs"; $atc="atc"; $aec="aec";
if(isset($_POST['username']) && isset($_POST['password']))
{
    // connexion à la base de données
    $db_username = 'root';
    $db_password = '';
    $db_name     = 'abonnement';
    $db_host     = 'localhost';
    $db = mysqli_connect($db_host, $db_username, $db_password,$db_name)
           or die('vous ne pouvez pas vous connecter à la base de données');
    
    // on applique les deux fonctions mysqli_real_escape_string et htmlspecialchars
    // pour éliminer toute attaque de type injection SQL et XSS
    $username = mysqli_real_escape_string($db,htmlspecialchars($_POST['username'])); 
    $password = mysqli_real_escape_string($db,htmlspecialchars($_POST['password']));
    
    if($username !== "" && $password !== "")
    {
        $requete = "SELECT count(*) FROM utilisateur where 
              nom_utilisateur = '".$username."' and mot_de_passe = '".$password."' ";
        $exec_requete = mysqli_query($db,$requete);
        $reponse      = mysqli_fetch_array($exec_requete);
        $count = $reponse['count(*)'];
        if($count!=0) // nom d'utilisateur et mot de passe correctes
        {
           $_SESSION['username'] = $username;
           if ($pers==$client) {
            header('Location: 8FormAccordClient.php');
           }/*elseif($pers==$at){
            header('Location: ');
           }elseif($pers==$client){
            header('Location: ');
           }elseif($pers==$caisse){
            header('Location: ');
           }elseif($pers==$rc ){
            header('Location: ');
           }elseif($pers==$atc){
            header('Location: ');
           }elseif($pers==$aec){
            header('Location: ');
           }elseif($pers==$rgs){
            header('Location: ');
           }
           */elseif($pers==$rt){
            header('Location: 5FormValidationMetrie.php');  
           }else{
              header('Location: 1FormQualification.php');// redirection sur la page principale  
           }
        }
        else
        {
           header('Location: index.php?erreur=1'); // utilisateur ou mot de passe incorrect
        }
    }
    else
    { 
       header('Location: login.php?erreur=2'); // utilisateur ou mot de passe vide
    }
}
else
{ //mettre un if ici pour gerer les sessions 
   header('Location: login.php');
  
}
mysqli_close($db); // fermeture de la connexion
?>