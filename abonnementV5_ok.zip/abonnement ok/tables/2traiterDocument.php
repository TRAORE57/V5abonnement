<?php
//var_dump(($_POST));exit;
//var_dump($_FILES);exit;
$uploadpiece = 'fichiers/pieces/';
$uploadsecurel= 'fichiers/securels/';
//ajout des secondes au nom du fichier pour ne pas écraser l'autre fichier
$uploadfile = $uploadpiece.time().'-'. basename($_FILES['jointepiece']['name']);
//deplacement du fichier piece dans le repertoire destination
move_uploaded_file($_FILES['jointepiece']['tmp_name'], $uploadfile);
//ajout des secondes au nom du fichier pour ne pas écraser l'autre fichier
$uploadsecurels = $uploadsecurel.time().'-'. basename($_FILES['jointesecurel']['name']);
//deplacement du fichier securel  dans le repertoire destination
move_uploaded_file($_FILES['jointesecurel']['tmp_name'], $uploadsecurels);

// demarrage du processus et  envoyer des donnees à camunda 
require_once('camundaRestClient.php');
$restClient = new camundaRestClient('http://localhost:8080/engine-rest');
// recuperation et envoi des données du formulaire vers camunda  
$params=[
		"typepiece"=>['value'=>$_POST['typepiece'],'type'=>'string'],
		"numeropiece"=>['value'=>$_POST['numeropiece'],'type'=>'string'], 
		"agentcie"=>['value'=>$_POST['agentcie'],'type'=>'string'],
		"numerosecurel"=>['value'=>$_POST['numerosecurel'],'type'=>'string'],
		"referenceclient"=>['value'=>$_POST['referenceclient'],'type'=>'string'],
		"numerodemande"=>['value'=>$_POST['numerodemande'],'type'=>'string'],
		"jointepiece"=>['value'=>$uploadfile, 'type'=>'string'],
        "jointesecurel"=>['value'=>$uploadsecurels, 'type'=>'string']
		];
$params =['variables'=>$params];
//recuperation de s  tâches assignées à l'utilisateur 'ac'
$results = $restClient->getTasks(['assigned'=>true,'assignee'=>'ac']);
//var_dump($results);exit;
//recuperation de l'ID
$id= $results['0']->id;
//var_dump($id);exit;
//envoyer les données  et passer à l'étape planification
$envoyer = $restClient->postForm($id,$params);
header('Location: 3FormPlanification.php');

?>