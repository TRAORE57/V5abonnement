
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Demande d'abonnement-branchement</title>
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
<?php
$abonn="AB-".time()."2021";
$reference="Ref-".time()."2021";
//var_dump($abonn);exit;

?>
  <div class="container">
  <h1>BRANCHEMENT-ABONNEMENT</h1>
    <div class="title">DOCUMENTS NECESSAIRES</div>
    <div class="content">
      <form action="2traiterDocument.php" method="POST" enctype='multipart/form-data' >
        <div class="user-details">
          <div class="select-box">
            <span class="details"><strong>Pièce d'identité de l'abonné (type)</strong></span>
            <select name="typepiece" id="typepiece" required>
              <option value="">Selectionnez le type de pièce</option>
              <option value="permis">permis</option>
              <option value="passeport">passeport</option>
              <option value="Carte nationale d'identité">carte national d'identité</option>
              <option value="attestation d'identité">attestation</option>
            </select>
          </div>
          
          <div class="input-box">
            <span class="details"><strong>numéro de la pièce</strong></span>
            <input type="text" name="numeropiece" placeholder="Entrez lz numero de la pièce" required>
          </div>
          <div class="input-box">
            <span class="details"><strong>Joindre la pièce</strong></span>
            <input type="file" name="jointepiece" required>
          </div>
          
          <div class="select-box">
            <span class="details"><strong>êtes vous agent CIE ?</strong></span>
            <select name="agentcie" id="agentcie" required>
              <option value="">Selectionnez votre statut</option>
              <option value="OUI">OUI</option>
              <option value="NON">NON</option>
            </select>
          </div>
          <div class="input-box">
            <span class="details"><strong>Document securel</strong></span>
            <input type="file" name="jointesecurel" required>
          </div>
          <div class="input-box">
            <span class="details"><strong>Numéro securel</strong></span>
            <input type="text" name="numerosecurel" placeholder="LK0000032445AB" required>
          </div>
          <div class="input-box">
            <span class="details"><strong>Référence du client</strong></span>
            <input type="text" value="<?=$reference?>" name="referenceclient" readonly>
          </div>
          <div class="input-box">
            <span class="details"><strong>Numero de demande</strong></span>
            <input type="text" value="<?=$abonn?>" name="numerodemande" readonly>
          </div>
        </div> 
        <div class="button">
          <input type="submit" value="Envoyer">
        </div>
      </form>
    </div>
  </div>

</body>
</html>
