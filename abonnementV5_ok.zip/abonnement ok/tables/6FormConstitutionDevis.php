
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Demande d'abonnement-branchement</title>
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
<?php
 // demarrage du processus et  envoyer des donnees à camunda 
require_once('camundaRestClient.php');
$restClient = new camundaRestClient('http://localhost:8080/engine-rest');
$processeid =$restClient->getProcessInstances();
$variables=$restClient->getProcessVariables($processeid['0']->id);
//var_dump($variables); exit;
?>
  <div class="container">
  <h1>BRANCHEMENT-ABONNEMENT</h1>
    <div class="title">CONSTITUTION DE DEVIS</div>
    <div class="content">
      <form action="6traiterConstitutionDevis.php" method="POST" enctype='multipart/form-data' >
        <div class="user-details">
        <div class="input-box">
            <span class="details"><strong>Materiel ou amperage :</strong></span>
            <input type="text" value="<?=$variables->materiel->value?>" name="materiel" readonly>
          </div>
          <div class="input-box">
            <span class="details"><strong>Coût du materiel :</strong></span>
            <input type="number" placeholder=" 50 000" name="coutMateriel" required>
          </div>
          <div class="input-box">
            <span class="details"><strong>Coût de la main d'ouevre :</strong></span>
            <input type="number" placeholder=" 20 000" name="coutMain" required>
          </div>
          <div class="input-box">
            <span class="details"><strong>Montant total : </strong></span>
            <input type="number" placeholder=" 70 000" name="total" required>
          </div>
          <div class="input-box">
            <span class="details"><strong>Type de compteur :</strong></span>
            <input type="text" value="<?=$variables->rapportterrain->value?>" name="rapportterrain" readonly>
          </div>

        <div class="button">
          <input type="submit" value="Continuer">
        </div>
      </form>
    </div>
  </div>

</body>
</html>
